package ru.springshop.dao;

import org.springframework.stereotype.Component;
import ru.springshop.models.Order;
import ru.springshop.models.Product;
import ru.springshop.models.ShopHelper;
import ru.springshop.models.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

@Component
public class OrderDAO {
    private int ID_COUNT;
    private List<Order> orders;

    public OrderDAO(){
        orders = new ArrayList<>();
    }

    public void setAllVisible(){
        for (Order order : orders){
            order.setVisible(true);
        }
    }

    public void setVisibleUser(User user){
        for (Order order : orders){
            if (order.getUser().getId() != user.getId()){
                order.setVisible(false);
            }
        }
    }

    public void find(String value){
        setAllVisible();
        if (value.length() != 4)
            return;
        for (Order order : orders){
            order.setVisible(order.getName().substring(order.getName().length() - 4).equalsIgnoreCase(value));
        }
    }

    public List<Order> getAll(){
        return orders;
    }

    public Order get(int id){
        return orders.stream().filter(product -> product.getId() == id).findAny().orElse(null);
    }


    public void addOrder(User user){
        List<Product> products = user.getProducts();
        List<Product> newProducts = new ArrayList<>();
        for (Product product : products)
            newProducts.add(new Product(product));

        user.setProducts(new ArrayList<>());
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
        String date = dateFormat.format(new Date());
        int randomNum = ThreadLocalRandom.current().nextInt(10000, 100000);
        orders.add(new Order(++ID_COUNT, Integer.toString(randomNum), newProducts, date, user));
    }
}
