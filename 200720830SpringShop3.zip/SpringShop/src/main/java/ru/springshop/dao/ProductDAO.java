package ru.springshop.dao;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import ru.springshop.models.Product;
import ru.springshop.models.ShopHelper;

import java.util.*;

@Component
public class ProductDAO {
    private int ID_COUNT = 4;
    private List<Product> products;

    public ProductDAO(){
        products = new ArrayList<>();
        products.add(new Product(1, "Milk", 58, 30));
        products.add(new Product(2, "Bread", 24, 24));
        products.add(new Product(3, "Chocolate", 120, 18));
        products.add(new Product(4, "Water", 65, 28));
    }

    public boolean hasImage(int id){
        return ! Objects.equals(get(id).getImage(), "");
    }

    public void find(ShopHelper shopHelper){
        String name = shopHelper.getValue();
        for (Product product : products){
            product.setVisible(product.getName().equalsIgnoreCase(name));
        }
    }

    public void sort(ShopHelper shopHelper){
        String key = shopHelper.getKey();
        String value = shopHelper.getValue();
        if (Objects.equals(key, "name"))
            if (Objects.equals(value, "ascending"))
                products.sort(Comparator.comparing(Product::getName));
            else
                products.sort(Comparator.comparing(Product::getName, Collections.reverseOrder()));
        else if (Objects.equals(key, "cost"))
            if (Objects.equals(value, "ascending"))
                products.sort(Comparator.comparing(Product::getCost));
            else
                products.sort(Comparator.comparing(Product::getCost, Collections.reverseOrder()));
        else
            if (Objects.equals(value, "ascending"))
                    products.sort(Comparator.comparing(Product::getCount));
                else
                    products.sort(Comparator.comparing(Product::getCount, Collections.reverseOrder()));
    }

    public void filter(ShopHelper shopHelper){
        String key = shopHelper.getKey();
        String sign = shopHelper.getSign();
        int value = Integer.parseInt(shopHelper.getValue());
        for (Product product : products){
            if (Objects.equals(key, "cost"))
                if (Objects.equals(sign, "less"))
                    product.setVisible(product.getCost() < value);
                else
                    product.setVisible(product.getCost() > value);
            else
                if (Objects.equals(sign, "less"))
                    product.setVisible(product.getCount() < value);
                else
                    product.setVisible(product.getCount() > value);
        }
    }

    public void setAllVisible(){
        for (Product product : products){
            product.setVisible(true);
        }
    }

    public List<Product> getAll(){
        return products;
    }

    public Product get(int id){
        return products.stream().filter(product -> product.getId() == id).findAny().orElse(null);
    }

    public void add(Product product){
        product.setId(++ID_COUNT);
        products.add(product);
    }

    public void edit(int id, Product newProduct){
        Product oldProduct = get(id);

        oldProduct.setName(newProduct.getName());
        oldProduct.setCost(newProduct.getCost());
        oldProduct.setCount(newProduct.getCount());
    }

    public void delete(int id){
        products.remove(get(id));
    }
}

