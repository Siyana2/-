package ru.springshop.dao;

import org.springframework.stereotype.Component;
import ru.springshop.models.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class UserDAO {
    private int ID_COUNT = 3;
    private List<User> users;
    private UserStatus userStatus;
    private int current;
    public UserStatus getUserStatus(){
        return userStatus;
    }

    public boolean isVisitor(){
        return userStatus == UserStatus.VISITOR;
    }

    public boolean isShopper(){
        return userStatus == UserStatus.SHOPPER;
    }

    public boolean isAdmin(){
        return userStatus == UserStatus.ADMIN;
    }

    public boolean isUserShopper(int id){
        System.out.println("is User Shopper" + getUser(id));
        return getUser(id) instanceof Shopper;
    }

    public Product getProduct(int id){
        return getCurrentUser().getProducts().stream().filter(prod -> prod.getId() == id).findAny().orElse(null);
    }

    public int getProductCount(int id){
        Product product = getProduct(id);
        if (product == null)
            return 0;
        return product.getCount();
    }

    public void changeProductCount(Product shopProduct, int count){
        int id = shopProduct.getId();
        Product userProduct = getProduct(id);
        if (userProduct == null) {
            userProduct = new Product(id, shopProduct.getName(), shopProduct.getCost(), 0);
            getCurrentUser().getProducts().add(userProduct);
        }
        userProduct.setCount(userProduct.getCount() + count);
        if (getProductCount(id) == 0)
            remProduct(id);
    }

    public void remProduct(int id){
        Product product = getProduct(id);
        for (Product prod : getCurrentUser().getProducts()) {
            if (prod.getId() == product.getId()) {
                getCurrentUser().getProducts().remove(prod);
                return;
            }
        }
    }

    public UserDAO(){
        users = new ArrayList<>();
        users.add(new Visitor(0, "visitor", "visitor", "visitor",
                "visitor@gmail.com", "visitor", "visitor"));
        users.add(new Admin(1, "admin", "admin", "admin",
                "admin@gmail.com", "admin", "admin"));
        users.add(new Shopper(2, "shopper", "shopper", "shopper",
                "shopper@gmail.com", "shopper", "shopper"));
        users.add(new Shopper(3, "shopper2", "shopper2", "shopper2",
                "shopper2@gmail.com", "shopper2", "shopper2"));
        userStatus = UserStatus.VISITOR;
        current = 0;
    }

    public void setUserStatus(UserStatus userStatus) {
        this.userStatus = userStatus;
    }

    public void changeUserStatus(int id){
        User user = getUser(id);
        if (user instanceof Visitor)
            userStatus = UserStatus.VISITOR;
        if (user instanceof Shopper)
            userStatus = UserStatus.SHOPPER;
        if (user instanceof Admin)
            userStatus = UserStatus.ADMIN;
    }

    public boolean enterSystem(Authorization authorization){
        for (User user : users){
            if (Objects.equals(user.getEmail(), authorization.getLoginEmail()) ||
                    Objects.equals(user.getLogin(), authorization.getLoginEmail())){
                if (Objects.equals(user.getPassword(), authorization.getPassword())){
                    current = user.getId();
                    changeUserStatus(current);
                    System.out.println(getCurrent());
                    return true;
                }
            }
        }
        return false;
    }

    public int getCurrent() {
        return current;
    }

    public User getCurrentUser(){
        return getUser(getCurrent());
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    public List<User> getAll(){
        return users;
    }

    public User getUser(int id){
        for (User user : users){
            if (user.getId() == id){
                return user;
            }
        }
        return null;
    }

    public void add(User user){
        user.setId(++ID_COUNT);
        users.add(user);
    }

    public void edit(int id, User newUser){
        User oldUser = getUser(id);

        oldUser.setSurname(newUser.getSurname());
        oldUser.setName(newUser.getName());
        oldUser.setPatronymic(newUser.getPatronymic());
        oldUser.setEmail(newUser.getEmail());
        oldUser.setLogin(newUser.getLogin());
        oldUser.setPassword(newUser.getPassword());
    }

    public void logOut(){
        current = 0;
        userStatus = UserStatus.VISITOR;
    }

    public void delete(int id){
        users.remove(getUser(id));
    }

}
