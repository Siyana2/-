package ru.springshop.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.springshop.dao.ProductDAO;
import ru.springshop.dao.UserDAO;
import ru.springshop.models.*;

import javax.validation.Valid;
import java.io.File;

@Controller
@RequestMapping("/users")
public class UsersController {
    UserDAO userDAO;

    ProductDAO productDAO;

    public UsersController(UserDAO userDAO, ProductDAO productDAO){
        this.userDAO = userDAO;
        this.productDAO = productDAO;
    }

    // HOME, ENTER, REGISTER, LOG IN, LOG OUT

    @GetMapping("/home")
    public String home(Model model){
        if (userDAO.isVisitor())
            return "redirect:/users/enter";
        model.addAttribute("isAdmin", userDAO.isAdmin());
        model.addAttribute("isVisitor", userDAO.isVisitor());
        return "users/home";
    }

    @GetMapping("/enter")
    public String enter(){
        if (! userDAO.isVisitor())
            return "redirect:/users/home";
        return "users/enter";
    }

    @GetMapping("/register")
    public String register(@ModelAttribute("user") @Valid Shopper user){
        if (! userDAO.isVisitor())
            return "redirect:/users/home";
        return "users/new";
    }

    @GetMapping("/authorization")
    public String getAuthorize(@ModelAttribute("authorization") @Valid Authorization authorization){
        if (! userDAO.isVisitor())
            return "redirect:/users/home";
        return "users/authorization";
    }

    @PostMapping("/home")
    public String postAuthorize(@ModelAttribute("authorization") @Valid Authorization authorization,
                              BindingResult bindingResult){
        if (! userDAO.isVisitor())
            return "redirect:/users/home";

        if (bindingResult.hasErrors())
            return "users/authorization";

        if (! userDAO.enterSystem(authorization))
            return "users/authorization";

        return "redirect:/users/home";
    }

    @GetMapping("/log_out")
    public String logOut(){
        if (! userDAO.isVisitor())
            userDAO.logOut();
        return "users/enter";
    }

    // PRODUCTS: ADD, REM

    @PostMapping("incProduct/{id}")
    public String incProduct(@PathVariable("id") int id,
                             @ModelAttribute("count") Count count){
        Product product = productDAO.get(id);
        if (count.getCount() > 0 && count.getCount() <= product.getCount()){
            userDAO.changeProductCount(product, count.getCount());
            product.setCount(product.getCount() - count.getCount());
        }

        return "redirect:/products/" + id;
    }

    @PostMapping("decProduct/{id}")
    public String decProduct(@PathVariable("id") int id,
                             @ModelAttribute("count") Count count){
        Product product = productDAO.get(id);
        if (count.getCount() > 0 && count.getCount() <= userDAO.getProductCount(id)){
            userDAO.changeProductCount(product, - count.getCount());
            product.setCount(product.getCount() + count.getCount());
        }

        return "redirect:/products/" + id;
    }

    // USERS: ALL, GET, CREATE, EDIT, DELETE

    @GetMapping()
    public String getAll(Model model){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        model.addAttribute("users", userDAO.getAll());
        model.addAttribute("current", userDAO.getUser(userDAO.getCurrent()));
        return "users/all";
    }

    @GetMapping("/{id}")
    public String get(@PathVariable("id") int id, Model model){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        model.addAttribute("user", userDAO.getUser(id));
        model.addAttribute("userDAO", userDAO);
        return "users/get";
    }

    @GetMapping("/new")
    public String formCreateUser(@ModelAttribute("user") Shopper user){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        return "users/new";
    }

    @PostMapping()
    public String postCreateUser(@ModelAttribute("user") @Valid Shopper user,
                         BindingResult bindingResult){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        if (bindingResult.hasErrors())
            return "users/new";

        userDAO.add(user);
        return "redirect:/users";
    }

    @GetMapping("/{id}/edit")
    public String getEdit(Model model, @PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        model.addAttribute("user", userDAO.getUser(id));
        return "users/edit";
    }

    @PatchMapping("/{id}")
    public String postEdit(@ModelAttribute("user") @Valid Visitor user,
                         BindingResult bindingResult,
                         @PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        if (bindingResult.hasErrors())
            return "users/edit";

        userDAO.edit(id, user);
        return "redirect:/users";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/home";

        if (userDAO.getCurrent() != id)
            userDAO.delete(id);

        return "redirect:/users";
    }

    @PostMapping("/{id}/upgrade")
    public String upgradeUser(@PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        User user = userDAO.getUser(id);

        userDAO.add(new Admin(String.copyValueOf(user.getSurname().toCharArray()),
                String.copyValueOf(user.getName().toCharArray()), String.copyValueOf(user.getPatronymic().toCharArray()),
                String.copyValueOf(user.getEmail().toCharArray()), String.copyValueOf(user.getLogin().toCharArray()),
                String.copyValueOf(user.getPassword().toCharArray())));
        userDAO.delete(user.getId());

        return "redirect:/users";
    }
}
