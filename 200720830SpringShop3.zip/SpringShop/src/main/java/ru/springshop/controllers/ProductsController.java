package ru.springshop.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.springshop.dao.ProductDAO;
import ru.springshop.dao.UserDAO;
import ru.springshop.models.Count;
import ru.springshop.models.Product;
import ru.springshop.models.ShopHelper;

import javax.validation.Valid;

@Controller
@RequestMapping("/products")
public class ProductsController {
    ProductDAO productDAO;
    UserDAO userDAO;

    public ProductsController(ProductDAO productDAO, UserDAO userDAO){
        this.productDAO = productDAO;
        this.userDAO = userDAO;
    }

    @GetMapping("/basket")
    public String basket(Model model){
        if (! userDAO.isShopper())
            return "redirect:/products";

        model.addAttribute("products", userDAO.getCurrentUser().getProducts());
        model.addAttribute("notEmpty", userDAO.getCurrentUser().getProducts().size() != 0);
        return "products/basket";
    }

    @PostMapping("find")
    public String find(@ModelAttribute("shopHelper") @Valid ShopHelper shopHelper, BindingResult bindingResult){
        if (! userDAO.isVisitor() && ! bindingResult.hasErrors())
            productDAO.find(shopHelper);

        return "redirect:/products/helper";
    }

    @PostMapping("sort")
    public String sort(@ModelAttribute("shopHelper") @Valid ShopHelper shopHelper, BindingResult bindingResult){
        if (! userDAO.isVisitor() && ! bindingResult.hasErrors())
            productDAO.sort(shopHelper);

        return "redirect:/products/helper";
    }

    @PostMapping("filter")
    public String filter(@ModelAttribute("shopHelper") @Valid ShopHelper shopHelper, BindingResult bindingResult){
        if (! userDAO.isVisitor() && ! bindingResult.hasErrors())
            productDAO.filter(shopHelper);

        return "redirect:/products/helper";
    }

    @PostMapping("{id}/addImage")
    public String addImage(@ModelAttribute("shopHelper") @Valid ShopHelper shopHelper, BindingResult bindingResult,
                           @PathVariable("id") int id){
        if (userDAO.isAdmin() && ! bindingResult.hasErrors())
            productDAO.get(id).setImage(shopHelper.getValue());

        return "redirect:/products";
    }

    public void addModelsALl(Model model){
        model.addAttribute("products", productDAO.getAll());
        model.addAttribute("userDAO", userDAO);
        model.addAttribute("shopHelper", new ShopHelper());
        model.addAttribute("isVisitor", userDAO.isVisitor());
        model.addAttribute("isShopper", userDAO.isShopper());
        model.addAttribute("isAdmin", userDAO.isAdmin());
    }

    @GetMapping()
    public String getAll(Model model){
        productDAO.setAllVisible();
        addModelsALl(model);
        return "products/all";
    }

    @GetMapping("/helper")
    public String getAllHelper(Model model){
        addModelsALl(model);
        return "products/all";
    }

    @GetMapping("/{id}")
    public String get(@PathVariable("id") int id, Model model){
        model.addAttribute("product", productDAO.get(id));
        model.addAttribute("userDAO", userDAO);
        model.addAttribute("productDAO", productDAO);
        model.addAttribute("shopHelper", new ShopHelper());
        model.addAttribute("isVisitor", userDAO.isVisitor());
        model.addAttribute("isShopper", userDAO.isShopper());
        model.addAttribute("isAdmin", userDAO.isAdmin());
        model.addAttribute("count", new Count());

        return "products/get";
    }

    @GetMapping("/new")
    public String newProduct(@ModelAttribute("product") Product product){
        if (! userDAO.isAdmin())
            return "redirect:/products";

        return "products/new";
    }

    @PostMapping()
    public String create(@ModelAttribute("product") @Valid Product product,
                         BindingResult bindingResult){
        if (! userDAO.isAdmin())
            return "redirect:/products";

        if (bindingResult.hasErrors())
            return "products/new";

        productDAO.add(product);
        return "redirect:/products";
    }

    @GetMapping("/{id}/edit")
    public String edit(Model model, @PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/products";

        model.addAttribute("product", productDAO.get(id));
        return "products/edit";
    }

    @PatchMapping("/{id}")
    public String update(@ModelAttribute("product") @Valid Product product,
                         BindingResult bindingResult,
                         @PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/products";

        if (bindingResult.hasErrors())
            return "/products/edit";

        productDAO.edit(id, product);
        return "redirect:/products";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/products";

        productDAO.delete(id);
        return "redirect:/products";
    }
}

















