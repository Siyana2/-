package ru.springshop.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import ru.springshop.dao.OrderDAO;
import ru.springshop.dao.UserDAO;
import ru.springshop.models.*;

import javax.validation.Valid;

@Controller
@RequestMapping("/orders")
public class OrderController {
    UserDAO userDAO;
    OrderDAO orderDAO;

    public OrderController(UserDAO userDAO, OrderDAO orderDAO){
        this.userDAO = userDAO;
        this.orderDAO = orderDAO;
    }

    public void addModelsALl(Model model){
        model.addAttribute("orders", orderDAO.getAll());
        model.addAttribute("userDAO", userDAO);
        model.addAttribute("shopHelper", new ShopHelper());
        model.addAttribute("isShopper", userDAO.isShopper());
        model.addAttribute("isAdmin", userDAO.isAdmin());
        if (userDAO.isShopper())
            orderDAO.setVisibleUser(userDAO.getCurrentUser());
    }

    @GetMapping()
    public String getAll(Model model){
        orderDAO.setAllVisible();
        addModelsALl(model);
        return "orders/all";
    }

    @GetMapping("/helper")
    public String getAllHelper(Model model){
        addModelsALl(model);
        return "orders/all";
    }

    @GetMapping("/{id}")
    public String get(@PathVariable("id") int id, Model model){
        model.addAttribute("order", orderDAO.get(id));
        model.addAttribute("userDAO", userDAO);
        model.addAttribute("isShopper", userDAO.isShopper());
        model.addAttribute("isAdmin", userDAO.isAdmin());
        model.addAttribute("count", new Count());

        return "orders/get";
    }

    @GetMapping("/new")
    public String newOrder(Model model){
        if (! userDAO.isShopper())
            return "redirect:/products";

        model.addAttribute("products", userDAO.getCurrentUser().getProducts());
        return "orders/new";
    }

    @GetMapping("/paid")
    public String paid(Model model){
        if (! userDAO.isShopper())
            return "redirect:/products";

        orderDAO.addOrder(userDAO.getCurrentUser());
        return "orders/paid";
    }

    @PostMapping("/{id}/archive")
    public String archiveOrder(@PathVariable("id") int id){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        Order order = orderDAO.get(id);
        order.setOld(true);

        return "redirect:/orders";
    }

    @PostMapping("/find")
    public String findOrder(@ModelAttribute("shopHelper") @Valid ShopHelper shopHelper, BindingResult bindingResult){
        if (! userDAO.isAdmin())
            return "redirect:/users/home";

        orderDAO.find(shopHelper.getValue());

        return "redirect:/orders/helper";
    }
}
