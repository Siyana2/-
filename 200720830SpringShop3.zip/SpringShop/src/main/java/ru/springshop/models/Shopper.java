package ru.springshop.models;

public class Shopper extends User{
    public Shopper(){}
    public Shopper(int id, String surname, String name, String patronymic, String email, String login, String password) {
        super(id, surname, name, patronymic, email, login, password);
    }

    public Shopper(String surname, String name, String patronymic, String email, String login, String password) {
        super(surname, name, patronymic, email, login, password);
    }
}
