package ru.springshop.models;

public enum UserStatus {
    VISITOR,
    SHOPPER,
    ADMIN
}
