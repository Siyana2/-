package ru.springshop.models;

public class Admin extends User{
    public Admin(){}
    public Admin(int id, String surname, String name, String patronymic, String email, String login, String password) {
        super(id, surname, name, patronymic, email, login, password);
    }

    public Admin(String surname, String name, String patronymic, String email, String login, String password) {
        super(surname, name, patronymic, email, login, password);
    }

}
