package ru.springshop.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public abstract class User {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private String encryption = "dkjafwpfajf";

    private String surname;
    private String name;
    private String patronymic;
    private String email;
    private String login;
    private String password;
    private List<Product> products;
    private List<List<Product>> orders;
    Scanner console;
    public User(){
        console = new Scanner(System.in);
        products = new ArrayList<>();
        orders = new ArrayList<>();
    }

    public User(int id, String surname, String name, String patronymic, String email, String login, String password) {
        this.id = id;
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.email = email;
        this.login = login;
        setPassword(password);
        products = new ArrayList<>();
        orders = new ArrayList<>();
        console = new Scanner(System.in);
    }

    public User(String surname, String name, String patronymic, String email, String login, String password) {
        this.surname = surname;
        this.name = name;
        this.patronymic = patronymic;
        this.email = email;
        this.login = login;
        setPassword(password);
        products = new ArrayList<>();
        orders = new ArrayList<>();
        console = new Scanner(System.in);
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPatronymic() {
        return patronymic;
    }

    public void setPatronymic(String patronymic) {
        this.patronymic = patronymic;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password.substring(0, password.length() - encryption.length());
    }

    public void setPassword(String password) {
        password += encryption;
        this.password = password;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public List<List<Product>> getOrders() {
        return orders;
    }

    public void setOrders(List<List<Product>> orders) {
        this.orders = orders;
    }
}
