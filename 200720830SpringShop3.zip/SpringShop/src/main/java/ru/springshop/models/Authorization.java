package ru.springshop.models;

public class Authorization {
    private String loginEmail;
    private String password;

    public Authorization() {
    }

    public Authorization(String loginEmail, String password) {
        this.loginEmail = loginEmail;
        this.password = password;
    }

    public String getLoginEmail() {
        return loginEmail;
    }

    public void setLoginEmail(String loginEmail) {
        this.loginEmail = loginEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
