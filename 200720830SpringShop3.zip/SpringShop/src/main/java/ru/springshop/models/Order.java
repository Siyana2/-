package ru.springshop.models;

import java.util.List;

public class Order {
    private int id;
    String name;
    private List<Product> products;
    private String date;
    private boolean visible;
    private User user;
    private boolean old;

    public Order() {
    }

    public Order(int id, String name, List<Product> products, String date, User user) {
        this.id = id;
        this.name = name;
        this.products = products;
        this.date = date;
        this.visible = true;
        this.user = user;
        this.old = false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Order(String name, List<Product> products, String date, User user) {
        this.name = name;
        this.products = products;
        this.date = date;
        this.visible = true;
        this.user = user;
        this.old = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public boolean isOld() {
        return old;
    }

    public void setOld(boolean old) {
        this.old = old;
    }
}
