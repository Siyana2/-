package ru.springshop.models;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class Product {
    private int id;
    private String image;
    @NotEmpty(message = "Name shouldn`t be empty")
    @Size(min = 2, message = "Name should be longer")
    @Size(max = 30, message = "Name should be shorter")
    private String name;
    @Positive
    private double cost;
    private int count;

    private boolean visible;

    public Product(){}

    public Product(int id, String name, double cost, int count) {
        this.id = id;
        this.image = "";
        this.name = name;
        this.cost = cost;
        this.count = count;
        this.visible = true;
    }

    public Product(Product product) {
        this.id = product.id;
        this.image = product.image;
        this.name = product.name;
        this.cost = product.cost;
        this.count = product.count;
        this.visible = true;
    }

    public Product(String name, double cost, int count) {
        this.image = "";
        this.name = name;
        this.cost = cost;
        this.count = count;
        this.visible = true;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public boolean isVisible() {
        return visible;
    }

    public String getImage() {
        System.out.println(image);
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
